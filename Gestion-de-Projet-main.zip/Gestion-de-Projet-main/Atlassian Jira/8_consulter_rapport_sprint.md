# Étape 8 : Consulter le rapport de sprint

À tout moment pendant ou après le sprint, vous pouvez consulter le rapport de sprint pour suivre l'évolution du sprint.

> RAPPEL : QU'EST-CE QUE LE RAPPORT DE SPRINT ?
> 
> Le rapport de sprint comprend le Burndown Chart et liste le travail achevé, le travail non achevé et tout travail ajouté après le début du sprint.
