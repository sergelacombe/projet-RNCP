# Étape 15 : Utilisation de wallboards (scrum avancé)
Compte tenu de tout ce qui se passe dans votre projet, il vaut la peine d'envisager l'utilisation de tableaux muraux pour permettre à votre équipe de se mettre au courant en un clin d'œil. Connectez votre ordinateur à un écran de télévision et voilà ! Votre tableau de bord Jira Software est maintenant un tableau mural physique - avec la puissance des gadgets agiles de Jira Software montrant les progrès de votre équipe en temps réel.

![wallboard-7](https://github.com/doudi0101/GdP/assets/73080397/928718ee-c9fb-49b5-a8e1-48e8a677179f)

Pour plus d'informations sur la configuration du tableau de bord et du tableau mural, voir [Configuration des tableaux de bord](http://confluence.atlassian.com/display/JIRASOFTWARECLOUD/Configuring+dashboards).
