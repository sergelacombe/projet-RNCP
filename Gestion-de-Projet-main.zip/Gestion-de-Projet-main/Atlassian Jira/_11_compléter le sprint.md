# Étape 11 : Terminer le sprint dans Jira

À la fin du sprint, vous devez le terminer.

![image4](https://github.com/doudi0101/GdP/assets/73080397/523aec3b-fe24-4c06-8311-8985c69ab218)

Si le sprint comporte des problèmes incomplets, vous pouvez :

* Déplacer le(s) problème(s) vers le backlog.
* Déplacer le(s) problème(s) vers un prochain sprint.
* Déplacer le(s) problème(s) vers un nouveau sprint, que Jira créera pour vous.
