# Étape 12 : Reprendre à partir de l'étape 2

À ce stade, vous avez acquis les bases pour construire votre backlog avec des user stories, organiser vos user stories en sprints, démarrer votre sprint et organiser des événements Scrum. Vous pouvez décider si cela fonctionne pour votre équipe ou si vous souhaitez passer à des sujets plus avancés.
